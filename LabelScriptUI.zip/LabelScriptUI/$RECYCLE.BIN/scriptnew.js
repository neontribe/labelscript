function Clear() {
    document.getElementById("scriptarea").InnerHTML = "hico";
};