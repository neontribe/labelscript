var i = true;
var o = false;
var c = "filled-in-box"
var r = [
    o,o,o,o,o,o,o,o,
    o,o,o,o,o,o,o,o,
    o,o,o,o,o,o,o,o,
    o,o,o,o,o,o,o,o
];
var itemone = [
    o,i,o,i,o,i,o,i,
    i,o,i,o,i,o,i,o,
    o,i,o,i,o,i,o,i,
    i,o,i,o,i,o,i,o
];
var itemtwo = [
    o,i,o,i,o,i,o,i,
    i,i,i,i,i,i,i,o,
    o,i,i,i,i,i,i,i,
    i,o,i,o,i,o,i,o
];
var itemthree = [
    i,i,i,i,i,i,i,i,
    i,o,i,o,i,o,i,i,
    i,i,o,i,o,i,o,i,
    i,i,i,i,i,i,i,i
];
var itemnone = r

function ItemToR(item) {
    if (item == 1) {
        r = itemone;
    } else if (item == 2) {
        r = itemtwo;
    } else if (item == 3) {
        r = itemthree;
    } else {
        r = itemnone;
    };
    RunChecks();
};

function CheckIO(id, io) {
    document.getElementById(id).checked = io;
};

function RunChecks() {
CheckIO(c + "1", r[0])
CheckIO(c + "2", r[1])
CheckIO(c + "3", r[2])
CheckIO(c + "4", r[3])
CheckIO(c + "5", r[4])
CheckIO(c + "6", r[5])
CheckIO(c + "7", r[6])
CheckIO(c + "8", r[7])
CheckIO(c + "11", r[8])
CheckIO(c + "12", r[9])
CheckIO(c + "13", r[10])
CheckIO(c + "14", r[11])
CheckIO(c + "15", r[12])
CheckIO(c + "16", r[13])
CheckIO(c + "17", r[14])
CheckIO(c + "18", r[15])
CheckIO(c + "21", r[16])
CheckIO(c + "22", r[17])
CheckIO(c + "23", r[18])
CheckIO(c + "24", r[19])
CheckIO(c + "25", r[20])
CheckIO(c + "26", r[21])
CheckIO(c + "27", r[22])
CheckIO(c + "28", r[23])
CheckIO(c + "31", r[24])
CheckIO(c + "32", r[25])
CheckIO(c + "33", r[26])
CheckIO(c + "34", r[27])
CheckIO(c + "35", r[28])
CheckIO(c + "36", r[29])
CheckIO(c + "37", r[30])
CheckIO(c + "38", r[31])
}